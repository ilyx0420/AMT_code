import boto3
import os
import json
import re
import xmltodict
import pandas as pd
import time
import argparse
import sys
from datetime import datetime
import threading

class getMultipleHitsResult:
    def __init__(self):
        self.hit_file, self.production = self.get_user_command()
        self.mtk_client = self.connect_amt(self.production)
        self.assignment_id = []
        self.worker_id = []
        self.hit_ids = []
        self.result = []
        self.accept_time = []
        self.submit_time = []
        self.status = []

    def get_user_command(self):
        parser = argparse.ArgumentParser()
        parser.add_argument('-p', type=str, default="true", help="(optional) production, default value is true, set '-p false' for sandbox")
        parser.add_argument('-f', type=str, help="hit_info.csv file path, name of csv file can be different", required=True)
        
        args = parser.parse_args()
        production = {"false":False, "true":True}[args.p]
        hit_file = args.f

        if not os.path.exists(hit_file):
            print("Error: file %s does not exsit." % hit_file)
            sys.exit("System exit!")
        else:
            return(hit_file, production)

    def connect_amt(self, production_state):
        if production_state == False:
            endpoint_url = 'https://mturk-requester-sandbox.us-east-1.amazonaws.com'
        elif production_state == True:
            endpoint_url = 'https://mturk-requester.us-east-1.amazonaws.com'

        region_name = 'us-east-1'
        aws_access_key_id = os.environ["AWS_ACCESS_KEY_ID"]
        aws_secret_access_key = os.environ["AWS_SECRET_ACCESS_KEY"] 

        mtk_client = boto3.client(
            'mturk',
            endpoint_url=endpoint_url,
            region_name=region_name,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )

        return mtk_client

    def get_one_hit_result(self, hit_id):
        status_list = ['Submitted','Approved','Rejected']
        paginator = self.mtk_client.get_paginator('list_assignments_for_hit')
        hit_assignments = paginator.paginate(HITId=hit_id, PaginationConfig={'PageSize': 100})
        
        for assignment in hit_assignments:
            # print(assignment)
            for an in assignment['Assignments']:
                if an['AssignmentStatus'] not in status_list:
                    continue
                
                answer = json.loads(json.dumps(xmltodict.parse(an['Answer'])))["QuestionFormAnswers"]['Answer']
                
                if isinstance (answer,list):
                    answer_hit = {a["QuestionIdentifier"]:a["FreeText"] for a in answer}
                elif isinstance (answer,dict):
                    answer_hit = answer["FreeText"]

                self.assignment_id.append(an["AssignmentId"])
                self.worker_id.append(an["WorkerId"])
                self.hit_ids.append(hit_id)
                self.result.append(answer_hit)
                self.accept_time.append(str(an["AcceptTime"]))
                self.submit_time.append(str(an["SubmitTime"]))
                self.status.append(an['AssignmentStatus'])

        
    
    def get_all_hits_result(self):
        df = pd.read_csv(self.hit_file)
        for row in df.itertuples():
            # hit_num = "# hit " + str(getattr(row, "Index")+1)
            hit_id = getattr(row, "hit_id")
            try:
                hit_thread = threading.Thread(target=self.get_one_hit_result, name=hit_id, args=((hit_id, )))
                hit_thread.start()
            except Exception as e:
                print("Hit_id:%s, error:%s" % (hit_id, str(e)))
        

    def write_hits_result_to_csv(self):
        df = pd.DataFrame({
                "assignment_id": self.assignment_id,
                "hit_id": self.hit_ids,
                "worker_id": self.worker_id,
                "result": self.result,
                "status": self.status,
                "accept_time": self.accept_time,
                "submit_time": self.submit_time
            })
        fpath, fname = os.path.split(self.hit_file)
        df.to_csv(fpath + "/result_" + fname, index=False)
        

if __name__ == "__main__":
    hit_handler = getMultipleHitsResult()
    hit_handler.get_all_hits_result()

    while threading.activeCount()>1: # MainThread
        pass

    hit_handler.write_hits_result_to_csv()


