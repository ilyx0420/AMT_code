python disable_hits.py --hit_ids_file=examples/image_sentence/hit_ids.txt
