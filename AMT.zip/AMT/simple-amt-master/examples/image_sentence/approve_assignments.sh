python approve_assignments.py --hit_ids_file=examples/image_sentence/hit_ids.txt
