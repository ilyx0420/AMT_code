$(document).ready(function() {
    // TODO: remove, distribute image urls 
    initImage.init();
    // splitImageUrls.init();
    getDistortedImage.init();
    flickering.init();
    submitJND.init();
    saveData2CSV.init();
    nextImage.init();
    keyBoardInput.init();
    
});

var INIT_MAX_VAL = 100;
var min_val = 0;
var mid_val = 50;
var distorted_val = mid_val; // best quality 
var pre_distorted_val = distorted_val;
var max_val = INIT_MAX_VAL;
var decrease_flag = true;
var DECRE_STEP = 10;
var flickering_second = 5000;
var result = {};
var bg_img_idx = 0;
var bg_img_idx_max = 80;
var factor = 100;
//-------------------
var imgurls = [];
var distorted_img = "";
var flicker = null;
var bg_img = "";
var freq = Math.round(1000/8);//ms

var curr_img_count = 0;
var test_img_num = 2; //numer of src images
var test_img_src_list = [12, 26, 43, 5, 32, 4, 14, 36, 48, 17]; // number of images must the same as test_img_num
var mode = "online";//online/offline

var splitImageUrls = (function() {
    function init() {
        imgurls = $(".imgpanel").attr("imgurls").split(";");
        bg_img = $(".imgpanel").attr("bg_img")
        mid_val = Math.floor((min_val + max_val) / 2);
        distorted_val = mid_val;
        factor = 101 - distorted_val;
        distorted_img = imgurls[factor-1];
    }
    return {
        init: init
    };
})();

var loadImages = (function() {
    // TODO: 
})();

var keyBoardInput = (function() {
    function init() {
        document.onkeyup = function (event) {
            var e = event || window.event;
            var keyCode = e.keyCode || e.which;
            switch (keyCode) {
                case 37:
                    if ($(".yesBtn").attr("disabled") != "disabled") {
                        getDistortedImage.yesAction();
                    }
                    break;
                case 39:
                    if ($(".noBtn").attr("disabled") != "disabled") {
                        getDistortedImage.noAction();
                    }
                    break;
                case 13:
                    if($(".nextimg").css("display") == "inline-block") {
                        btnAnimation.init("nextimg");
                        nextImage.action();
                    } else if($(".jndsubmit").css("display") == "inline-block") {
                        btnAnimation.init("jndsubmit");
                        submitJND.action();
                    }
                    break;
                default:
                    break;
            }
        }
    }
    return {
        init: init
    };
})();

var btnAnimation = (function(btnclass) {
    function init(btnclass) {
        var re = new RegExp(".?btn-.*? ");
        // var cls = $("." + btnclass).attr('class').split(" ").find(t=>t.startwith("btn-"));
        var cls = $("." + btnclass).attr('class').split(" ").find(t=>t.startsWith("btn-"));

        $("." + btnclass).removeClass(cls);
        $("." + btnclass).addClass("btn-outline-secondary");
        btnInterval = setInterval (function() {
            $("." + btnclass).removeClass("btn-outline-secondary");
            $("." + btnclass).addClass(cls);
            clearInterval(btnInterval);
        }, 1000);
    }
    return {
      init: init
    };
})();

var nextImage = (function() {
    function init() {
        $(".nextimg").click(function(event){
            action();
        });
    }

    function action() {  
        console.log("==============================")
        $(".nextimg").css("display", "none");
        $(".seeFlickering").css("display", "inline");
        $(".dis_level").html(0);
        initImage.init();
    }

    return {
        init: init,
        action: action
    };
})();


var getDistortedImage = (function() {
    function init() {
        $(".noBtn, .yesBtn").click(function(){
            if ($(this).attr("class").indexOf("yesBtn")>=0) {
                yesAction();
            }
            
            if ($(this).attr("class").indexOf("noBtn")>=0) {
                noAction();
            }         
        });
    }

    function noAction() {
        pre_distorted_val = distorted_val;
        min_val = Math.ceil((3 * min_val + max_val) / 4);
        mid_val = Math.floor((min_val + max_val) / 2);
        distorted_val = mid_val;
        factor = 101 - distorted_val;
        distorted_img = imgurls[factor-1];
        

        if (distorted_val == pre_distorted_val){
        // if (distorted_val == max_val || max_val-distorted_val < min_val){
            $(".noBtn").attr("disabled", true);
            $(".yesBtn").attr("disabled", true);
            nextRefImg.init();
        }
        printInfo();
    }

    function yesAction() {
        pre_distorted_val = distorted_val;
        max_val = Math.floor((min_val + 3 * max_val) / 4);
        mid_val = Math.floor((min_val + max_val) / 2);
        distorted_val = mid_val;
        factor = 101 - distorted_val;
        distorted_img = imgurls[factor-1];

        if (distorted_val == pre_distorted_val){
            $(".noBtn").attr("disabled", true);
            $(".yesBtn").attr("disabled", true);
            nextRefImg.init();
        }
        printInfo();
    }

    function printInfo() {
        $(".dis_level").html(mid_val);
        console.log("min_val="+min_val
            +", mid_val="+(distorted_val)
            +", max_val="+max_val
            +", distorted_img="+distorted_img);
    }


    return {
      init: init,
      yesAction: yesAction,
      noAction: noAction
    };
})();

var flickering = (function() {
    var count = 0;
    function init() {
        flicker = setInterval (function() {
            if (distorted_val >= 0) {
                if (count%2 === 0) {
                    $(".image").attr("src", distorted_img);
                } else if (count%2 == 1) {
                    $(".image").attr("src", bg_img); //no distorsion
                }
                count++;
                count = count%2;
            }
        }, freq);
    }
    return {
        init: init
    };
})();

var submitJND = (function() {
    function init() {
        $(".jndsubmit").click(function(event){
            action();
        });
    }

    function action() {
        clearInterval(flicker);
        $(".jndsubmit").css("display", "none");
        $(".tocsv").css("display", "inline");
        // $(".image").attr("src", bg_img);
    }
    return {
        init: init,
        action: action
    };
})();

var nextRefImg = (function() {
    function init() {
        $(".noBtn").attr("disabled", true);
        $(".yesBtn").attr("disabled", true);
        $(".disfactor").css("display", "none");
        $(".msg").css("display", "inline");
        interval = setInterval (function() {
            action();
            $(".disfactor").css("display", "inline");
            $(".msg").css("display", "none");
            clearInterval(interval);
        }, 1000);
    }

    function action() {
        $(".noBtn").attr("disabled", false);
        $(".yesBtn").attr("disabled", false);

        var mydate = new Date();
        result[bg_img][0] = 101 - factor;
        result[bg_img][1] = factor; //image index, JND, Quality factor
        result[bg_img][3] = Date.parse(mydate);

        bg_img_idx += 10;
        if (bg_img_idx < bg_img_idx_max) {
            min_val = bg_img_idx; //min_val start from 1, bg_img_idx start from 0
            max_val = INIT_MAX_VAL;
            bg_img = imgurls[100-bg_img_idx];

            mid_val = Math.floor((min_val + max_val) / 2);
            distorted_val = mid_val;
            factor = 101 - distorted_val;
            distorted_img = imgurls[factor-1];



            $(".dis_level").html(mid_val);
            var mydate = new Date();
            result[bg_img] = ["", "", Date.parse(mydate), ""];
            console.log("N------------");
            console.log(result);
            console.log("New Ref Image: " + bg_img);
            console.log("Ref Img Idx: " + bg_img_idx);
            console.log("Distorted_val: " + distorted_val);
            console.log("Distorted_Img: " + distorted_img);
            console.log("Min Val: " + min_val);
            console.log("Mid Val: " + distorted_val);
            console.log("Max Val: " + max_val);
            console.log("------------N");
        } else {
            curr_img_count ++;
            $(".noBtn").attr("disabled", true);
            $(".yesBtn").attr("disabled", true);

            if (curr_img_count < test_img_num) {
                $(".nextimg").css("display", "inline");
                $(".dis_level").html(0);
            } else {
                $(".nextimg").css("display", "none");
                $(".jndsubmit").css("display", "inline");
            }
        }
    }
    return {
        init: init
    };
})();


var initImage = (function() {
    function init() {
        $(".noBtn").attr("disabled", false);
        $(".yesBtn").attr("disabled", false);
        new_img = test_img_src_list.shift();
        if (mode == "online") {
            bg_img = "https://datasets.vqa.mmsp-kn.de/MCL-JCI/ImageJND_SRC" + (Array(2).join("0") + new_img).slice(-2) + ".png";
        } else if (mode == "offline") {
            bg_img = "./MCL-JCI/ImageJND_SRC" + (Array(2).join("0") + new_img).slice(-2) + ".png";
        }
        
        var mydate = new Date();
        result[bg_img] = ["", "", Date.parse(mydate), ""];
        var imgurls = "";
        for (i=1; i<=100; i++) {
            if (mode == "online") {
                imgurls += "https://datasets.vqa.mmsp-kn.de/MCL-JCI/ImageJND_SRC" + (Array(2).join("0") + new_img).slice(-2) + "_" + (Array(3).join("0") + i).slice(-3) + ".jpg;";
            } else if (mode == "offline") {
                imgurls += "./MCL-JCI/ImageJND_SRC" + (Array(2).join("0") + new_img).slice(-2) + "_" + (Array(3).join("0") + i).slice(-3) + ".jpg;";
            }
        }
        $(".imgpanel").attr("imgurls", imgurls);
        $(".imgpanel").attr("bg_img", bg_img);
        $(".image").attr("src", bg_img);
        bg_img_idx = 0;
        min_val = 0;
        mid_val = 50;
        max_val = INIT_MAX_VAL;
        splitImageUrls.init();
        $(".dis_level").html(mid_val);

        console.log("N------------");
        console.log(result);
        console.log("New Ref Image: " + bg_img);
        console.log("Ref Img Idx: " + bg_img_idx);
        console.log("Distorted_Img: " + distorted_img);
        console.log("Min Val: " + min_val);
        console.log("Mid Val: " + 50);
        console.log("Max Val: " + max_val);
        console.log("------------N");
    }

    return {
        init: init
    };
})();

var saveData2CSV = (function() {
    var data = "";
    function init() {
        $(".tocsv").click(function(event){
            convertData();
            var mydate = new Date();
            $(".tocsv").attr("download", Date.parse(mydate)+"_bin.csv");
            $(".tocsv").attr("href", "data:text/csv;charset=utf-8," + data);
        });
    }

    function convertData() {
        // TODO: convert result json to string, add JND point to result
        var output = "";
        $.each(result, function(img, val) {
            output += img + "," + val[0] + "," + val[1] + "," + val[2] + "," + val[3] + "\n"
        })
        data = "Ref Image,Distortion Level,JND Point(IMG), Start Time, End Time\n" + output;
        data =  encodeURIComponent(data);
    }

    return {
        init: init
    };
})();
