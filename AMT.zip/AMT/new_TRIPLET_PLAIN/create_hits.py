import os
import boto3
from jinja2 import Template
import pandas as pd
import json
import time
import argparse
import sys


class createOneHit:
    def __init__(self, mtk_client, config):
        self.config = config
        self.mtk_client = mtk_client

    def getTemplate(self):
        with open('template.html') as html_fi:
            html_template = html_fi.read()
        with open('xml_template.xml') as xml_fi:
            xml_template = Template(xml_fi.read()).render(html_content=html_template)
            xml_template = Template(xml_template)
        return xml_template

    def createHitQuestionXml(self, xml_template, render_dict):
        hit_question_xml = xml_template.render(render_dict)
        # with open('hit.xml', "w") as hit_fi:
        #     hit_fi.write(hit_question_xml)
        return hit_question_xml
    
    def create_one_hit(self, hit_question_xml):
        hitConfig = self.config["HitConfig"]
        if self.config["RequireQualification"]:
            QualificationRequirements = hitConfig["QualificationRequirements"]
        else:
            QualificationRequirements = []

        new_hit = self.mtk_client.create_hit(
            Title="Compare Image Quality",
            Description = "Select the image you think looks more similar to the middle one.",
            Keywords = "Image Quality Comparison",
            Reward = "0.05",
            MaxAssignments =1,
            LifetimeInSeconds = 864000,  #1 day 86400,
            AssignmentDurationInSeconds = 600, # change !!!
            AutoApprovalDelayInSeconds = 604800, # CHANGE !!!!!! # 604800 7 days
            Question = hit_question_xml,
            QualificationRequirements=QualificationRequirements,
        )

        return (new_hit['HIT']['HITGroupId'], new_hit['HIT']['HITId'])

class createMultipleHits:
    def __init__(self):
        self.production, self.folder, self.config_path, self.html_template_path, self.dataset_path, self.public_name = self.get_user_command()
        self.mtk_client = self.get_user_confirmation()
        self.hiturl_list = []
        self.hitid_list = []

    def get_user_command(self):
        parser = argparse.ArgumentParser()
        parser.add_argument('-p', type=str, default="false", help="(optional) production, default value is false, set '-p true' for production")
        parser.add_argument('-n', type=str, default="", help="(optional) a name for this publication")
        parser.add_argument('-f', type=str, help="project folder path, folder must include config.json, template.html and data.csv", required=True)
        
        args = parser.parse_args()
        
        production = {"false":False, "true":True}[args.p]
        folder = args.f
        public_name = args.n

        # check folder
        if not os.path.exists(folder):
            print("Error: folder %s does not exsit." % args.f )
            sys.exit("System exit!")
        else:
            if folder.endswith("/"):
                folder = folder[:-1]

            # check files
            exit_sys = False 
            for f in ["config.json", "template.html", "data.csv"]:
                if not os.path.exists(folder + "/" + f):
                    print("Error: %s is not in folder %s" % (f, folder))
                    exit_sys = True
            if exit_sys: 
                sys.exit("System exit!")

            elif not exit_sys:
                config_path = folder + "/" + "config.json"
                html_template_path = folder + "/" + "template.html"
                dataset_path = folder + "/" + "data.csv"

        return(production, folder, config_path, html_template_path, dataset_path, public_name)


    def get_user_confirmation(self):
        try:
            if not self.production:
                mtk_client = self.connect_amt(self.production)
                print("*** Account has %s$ ***" % mtk_client.get_account_balance()['AvailableBalance'])
                print("Project will be created in *** SANDBOX *** environment.")
                
            elif self.production:
                mtk_client = self.connect_amt(self.production)
                print("*** Account has %s$ ***" % mtk_client.get_account_balance()['AvailableBalance'])
                confirm_config = "n"
                while confirm_config != "y":
                    confirm_config = input("Project will be created in *** PRODUCTION *** environment.\n \
                        please confirm (y/n): ")

                    if confirm_config == "n":
                        sys.exit("System exit!")

            return mtk_client

        except Exception as e:
            print("Error:%s" % str(e))
            return None

    def connect_amt(self, production_state):
        if production_state == False:
            endpoint_url = 'https://mturk-requester-sandbox.us-east-1.amazonaws.com'
        elif production_state == True:
            endpoint_url = 'https://mturk-requester.us-east-1.amazonaws.com'

        region_name = 'us-east-1'
        aws_access_key_id = os.environ["AWS_ACCESS_KEY_ID"]
        aws_secret_access_key = os.environ["AWS_SECRET_ACCESS_KEY"] 

        mtk_client = boto3.client(
            'mturk',
            endpoint_url=endpoint_url,
            region_name=region_name,
            aws_access_key_id=aws_access_key_id,
            aws_secret_access_key=aws_secret_access_key,
        )

        return mtk_client

    
    def createHits(self):
        with open(self.config_path) as json_file:
            config = json.load(json_file)

        onehit = createOneHit(self.mtk_client, config)
        xml_template = onehit.getTemplate() 

        data_df = pd.read_csv(self.dataset_path)
        template_keys = [n for n in data_df.columns.values.tolist() if n not in ["hit_id", "hit_url"]]

        for row in data_df.itertuples():
                print("# hit " + str(getattr(row, "Index")+1))
                # TODO: multiple threadings
                hit_question_xml = onehit.createHitQuestionXml(xml_template, {k:getattr(row, k) for k in template_keys})
                hit_group, hit_id= onehit.create_one_hit(hit_question_xml)  

                if self.production == False:
                    hit_url = "https://workersandbox.mturk.com/mturk/preview?groupId=" + hit_group
                    print("HITURL = " + hit_url)
                elif self.production == True:
                    hit_url = "https://worker.mturk.com/mturk/preview?groupId=" + hit_group
                
                self.hiturl_list.append(hit_url)
                self.hitid_list.append(hit_id)

    def writeHitInfo2Csv(self):
        if self.production == False:
            if not os.path.exists(self.folder+"/sandbox"):
                os.mkdir(self.folder+"/sandbox")
            new_folder = self.folder+"/sandbox"
        elif self.production == True:
            if not os.path.exists(self.folder+"/production"):
                os.mkdir(self.folder+"/production")
            new_folder = self.folder+"/production"

        new_folder = new_folder + "/%s_%s" % (self.public_name, time.strftime("%Y-%m-%d_%H-%M-%S"))
        os.mkdir(new_folder)

        df = pd.read_csv(self.dataset_path)
        df["hit_url"] = self.hiturl_list
        df["hit_id"] = self.hitid_list
        df.to_csv(new_folder + "/hit_info_%s.csv" % (self.public_name), index=False)

    def start(self):
        self.createHits()
        self.writeHitInfo2Csv()

if __name__ == "__main__":
    createMultipleHits().start()
